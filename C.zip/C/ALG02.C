/* ALG02 */
#include <stdio.h>
int X;
int main()
{
  scanf("%i", &X);
  printf("%i\n", X);
  return 0;
}

