/* ALG03 */
#include <stdio.h>
#include <math.h>
int X;
int Y;
int main()
{
  scanf("%i", &X);
  Y = pow(X, 2);
  printf("%i\n", Y);
  return 0;
}

