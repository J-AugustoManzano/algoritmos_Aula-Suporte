/* ALG06 */
#include <stdio.h>
int X;
int main()
{
  scanf("%i", &X);
  if (X > 100)
    printf("%i\n", X);
  return 0;
}

